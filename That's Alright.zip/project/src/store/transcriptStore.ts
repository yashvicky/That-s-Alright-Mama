import { create } from 'zustand';

interface TranscriptState {
  transcript: string;
  addToTranscript: (text: string) => void;
  clearTranscript: () => void;
}

export const useTranscriptStore = create<TranscriptState>((set) => ({
  transcript: '',
  addToTranscript: (text: string) =>
    set((state) => ({ transcript: state.transcript + ' ' + text })),
  clearTranscript: () => set({ transcript: '' }),
}));