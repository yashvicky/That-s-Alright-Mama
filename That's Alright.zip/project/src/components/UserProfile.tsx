import React, { useState, useEffect } from 'react';
import { Scale, Calculator, Calendar } from 'lucide-react';

interface UserData {
  age: number;
  weight: number; // in kg
  height: number; // in cm
  weekOfPregnancy: number;
}

export function UserProfile() {
  const [userData, setUserData] = useState<UserData>({
    age: 0,
    weight: 0,
    height: 0,
    weekOfPregnancy: 0,
  });

  const [bmi, setBmi] = useState<number>(0);
  const [weightGain, setWeightGain] = useState<string>('');

  const calculateBMI = () => {
    const heightInMeters = userData.height / 100;
    const bmiValue = userData.weight / (heightInMeters * heightInMeters);
    setBmi(Math.round(bmiValue * 10) / 10);
    
    // Recommended weight gain based on pre-pregnancy BMI
    if (bmiValue < 18.5) {
      setWeightGain('28-40 lbs (12.5-18 kg)');
    } else if (bmiValue < 24.9) {
      setWeightGain('25-35 lbs (11.5-16 kg)');
    } else if (bmiValue < 29.9) {
      setWeightGain('15-25 lbs (7-11.5 kg)');
    } else {
      setWeightGain('11-20 lbs (5-9 kg)');
    }
  };

  useEffect(() => {
    if (userData.weight && userData.height) {
      calculateBMI();
    }
  }, [userData.weight, userData.height]);

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold mb-6">Profile Information</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Age (years)
            </label>
            <input
              type="number"
              value={userData.age || ''}
              onChange={(e) => setUserData(prev => ({ ...prev, age: Number(e.target.value) }))}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Weight (kg)
            </label>
            <input
              type="number"
              step="0.1"
              value={userData.weight || ''}
              onChange={(e) => setUserData(prev => ({ ...prev, weight: Number(e.target.value) }))}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Height (cm)
            </label>
            <input
              type="number"
              value={userData.height || ''}
              onChange={(e) => setUserData(prev => ({ ...prev, height: Number(e.target.value) }))}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Week of Pregnancy
            </label>
            <input
              type="number"
              min="1"
              max="42"
              value={userData.weekOfPregnancy || ''}
              onChange={(e) => setUserData(prev => ({ ...prev, weekOfPregnancy: Number(e.target.value) }))}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200"
            />
          </div>
        </div>
      </div>

      {bmi > 0 && (
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <Calculator className="h-5 w-5 text-pink-500" />
              <h3 className="font-semibold">BMI Information</h3>
            </div>
            <p className="text-lg mb-2">Current BMI: <span className="font-semibold">{bmi}</span></p>
            <p className="text-sm text-gray-600">
              Recommended pregnancy weight gain: {weightGain}
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <Scale className="h-5 w-5 text-pink-500" />
              <h3 className="font-semibold">Daily Calorie Needs</h3>
            </div>
            <p className="text-lg mb-2">
              {Math.round(userData.weight * 30 + (userData.weekOfPregnancy > 13 ? 300 : 100))} calories
            </p>
            <p className="text-sm text-gray-600">
              Based on your weight and pregnancy stage
            </p>
          </div>
        </div>
      )}
    </div>
  );
}