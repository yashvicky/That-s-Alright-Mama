import React, { useState } from 'react';
import { Plus, Check, AlertTriangle, ThumbsUp } from 'lucide-react';

export function SymptomTracker() {
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [severityLevels, setSeverityLevels] = useState<Record<string, number>>({});

  const commonSymptoms = [
    'Morning Sickness',
    'Heartburn',
    'Fatigue',
    'Food Aversions',
    'Cravings',
    'Nausea',
    'Bloating',
    'Loss of Appetite',
  ];

  const toggleSymptom = (symptom: string) => {
    setSymptoms(prev =>
      prev.includes(symptom)
        ? prev.filter(s => s !== symptom)
        : [...prev, symptom]
    );
  };

  const updateSeverity = (symptom: string, level: number) => {
    setSeverityLevels(prev => ({
      ...prev,
      [symptom]: level
    }));
  };

  const getAIRecommendations = () => {
    const recommendations = {
      dietary: [] as string[],
      lifestyle: [] as string[],
      urgent: [] as string[]
    };

    // Complex symptom analysis
    const hasNausea = symptoms.includes('Nausea') || symptoms.includes('Morning Sickness');
    const hasDigestiveIssues = symptoms.includes('Heartburn') || symptoms.includes('Bloating');
    const hasEnergyIssues = symptoms.includes('Fatigue');
    const hasAppetiteIssues = symptoms.includes('Loss of Appetite') || symptoms.includes('Food Aversions');

    // Dietary recommendations based on symptom combinations
    if (hasNausea) {
      recommendations.dietary.push(
        'Eat small, frequent meals throughout the day',
        'Try ginger tea or ginger candies',
        'Keep crackers by your bedside for morning nausea'
      );
    }

    if (hasDigestiveIssues) {
      recommendations.dietary.push(
        'Avoid spicy and acidic foods',
        'Eat slowly and chew thoroughly',
        'Stay upright for 30 minutes after meals'
      );
    }

    if (hasEnergyIssues) {
      recommendations.dietary.push(
        'Include iron-rich foods like lean meats and leafy greens',
        'Add protein-rich snacks between meals',
        'Consider vitamin B-rich foods for energy'
      );
      recommendations.lifestyle.push(
        'Take short rest periods throughout the day',
        'Try light exercise like prenatal yoga',
        'Maintain a consistent sleep schedule'
      );
    }

    if (hasAppetiteIssues) {
      recommendations.dietary.push(
        'Focus on nutrient-dense foods',
        'Try cold foods if hot foods are unappealing',
        'Experiment with different textures'
      );
    }

    // Urgent recommendations based on severity
    const highSeveritySymptoms = Object.entries(severityLevels)
      .filter(([_, level]) => level >= 8);
    
    if (highSeveritySymptoms.length > 0) {
      recommendations.urgent.push(
        'Consider consulting your healthcare provider due to symptom severity',
        'Keep a detailed symptom diary to share with your doctor'
      );
    }

    return recommendations;
  };

  const recommendations = getAIRecommendations();

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold mb-6">Today's Symptoms</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {commonSymptoms.map(symptom => (
            <div key={symptom} className="space-y-2">
              <button
                onClick={() => toggleSymptom(symptom)}
                className={`w-full flex items-center justify-between p-4 rounded-lg border ${
                  symptoms.includes(symptom)
                    ? 'bg-pink-50 border-pink-300'
                    : 'bg-white border-gray-200 hover:border-pink-200'
                }`}
              >
                <span className="text-gray-700">{symptom}</span>
                {symptoms.includes(symptom) ? (
                  <Check className="h-5 w-5 text-pink-500" />
                ) : (
                  <Plus className="h-5 w-5 text-gray-400" />
                )}
              </button>
              
              {symptoms.includes(symptom) && (
                <div className="px-4">
                  <label className="text-sm text-gray-600 mb-1 block">
                    Severity (1-10):
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={severityLevels[symptom] || 5}
                    onChange={(e) => updateSeverity(symptom, parseInt(e.target.value))}
                    className="w-full accent-pink-500"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Mild</span>
                    <span>Severe</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      
      {symptoms.length > 0 && (
        <div className="space-y-6">
          {recommendations.urgent.length > 0 && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-center gap-2 text-amber-700 mb-2">
                <AlertTriangle className="h-5 w-5" />
                <h3 className="font-semibold">Important Notice</h3>
              </div>
              <ul className="list-disc list-inside space-y-2 text-amber-700">
                {recommendations.urgent.map((rec, index) => (
                  <li key={index}>{rec}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="p-4 bg-pink-50 rounded-lg">
            <div className="flex items-center gap-2 text-pink-700 mb-4">
              <ThumbsUp className="h-5 w-5" />
              <h3 className="font-semibold">Personalized Recommendations</h3>
            </div>
            
            {recommendations.dietary.length > 0 && (
              <div className="mb-4">
                <h4 className="font-medium mb-2">Dietary Suggestions:</h4>
                <ul className="list-disc list-inside space-y-2 text-gray-700">
                  {recommendations.dietary.map((rec, index) => (
                    <li key={index}>{rec}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {recommendations.lifestyle.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Lifestyle Tips:</h4>
                <ul className="list-disc list-inside space-y-2 text-gray-700">
                  {recommendations.lifestyle.map((rec, index) => (
                    <li key={index}>{rec}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}