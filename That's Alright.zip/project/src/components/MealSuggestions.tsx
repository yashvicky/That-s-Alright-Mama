import React from 'react';
import { Clock, Utensils } from 'lucide-react';

export function MealSuggestions() {
  const meals = [
    {
      title: 'Breakfast',
      suggestions: [
        {
          name: 'Oatmeal with Berries',
          description: 'Rich in fiber and antioxidants',
          image: 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?auto=format&fit=crop&w=600',
        },
        {
          name: 'Greek Yogurt Parfait',
          description: 'High in protein and calcium',
          image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600',
        },
      ],
    },
    {
      title: 'Lunch',
      suggestions: [
        {
          name: 'Quinoa Buddha Bowl',
          description: 'Packed with vegetables and protein',
          image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600',
        },
        {
          name: 'Salmon Salad',
          description: 'Essential omega-3 fatty acids',
          image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=600',
        },
      ],
    },
  ];

  return (
    <div>
      <h2 className="text-xl font-semibold mb-6">Healthy Meal Suggestions</h2>
      <div className="space-y-8">
        {meals.map(mealTime => (
          <div key={mealTime.title}>
            <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
              <Clock className="h-5 w-5 text-pink-500" />
              {mealTime.title}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mealTime.suggestions.map(meal => (
                <div
                  key={meal.name}
                  className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100"
                >
                  <img
                    src={meal.image}
                    alt={meal.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h4 className="font-medium text-gray-900 mb-1">{meal.name}</h4>
                    <p className="text-gray-600 text-sm">{meal.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}