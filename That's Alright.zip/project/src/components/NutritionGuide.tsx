import React from 'react';
import { Info, Apple } from 'lucide-react';

export function NutritionGuide() {
  const nutrients = [
    {
      name: 'Folic Acid',
      importance: "Critical for neural tube development",
      sources: ['Leafy greens', 'Fortified cereals', 'Legumes'],
      dailyNeeds: '600-800 mcg',
      calories: 'Low calorie'
    },
    {
      name: 'Iron',
      importance: "Prevents anemia and supports baby's growth",
      sources: ['Lean meats', 'Spinach', 'Beans'],
      dailyNeeds: '27 mg',
      calories: 'Varies by source'
    },
    {
      name: 'Calcium',
      importance: 'Builds strong bones and teeth',
      sources: ['Dairy products', 'Fortified plant milk', 'Tofu'],
      dailyNeeds: '1000 mg',
      calories: 'Moderate'
    },
    {
      name: 'Protein',
      importance: 'Essential for tissue growth and development',
      sources: ['Lean meats', 'Fish', 'Legumes', 'Eggs'],
      dailyNeeds: '75-100g',
      calories: 'High in protein sources'
    },
    {
      name: 'Omega-3 Fatty Acids',
      importance: 'Supports brain and eye development',
      sources: ['Salmon', 'Chia seeds', 'Walnuts'],
      dailyNeeds: '200-300mg DHA',
      calories: 'High in healthy fats'
    }
  ];

  const bmiBasedRecommendations = {
    underweight: {
      title: 'For BMI < 18.5',
      recommendations: [
        'Increase healthy calorie intake with nutrient-dense foods',
        'Add healthy fats like avocados and nuts',
        'Include protein with every meal',
        'Consider smaller, frequent meals'
      ]
    },
    normal: {
      title: 'For BMI 18.5-24.9',
      recommendations: [
        'Maintain balanced diet with variety',
        'Focus on whole grains and lean proteins',
        'Include plenty of fruits and vegetables',
        'Stay hydrated with water'
      ]
    },
    overweight: {
      title: 'For BMI 25-29.9',
      recommendations: [
        'Choose nutrient-dense, lower-calorie foods',
        'Emphasize lean proteins and vegetables',
        'Control portion sizes',
        'Stay active with approved exercises'
      ]
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold mb-6">Essential Nutrients Guide</h2>
        <div className="grid gap-6">
          {nutrients.map(nutrient => (
            <div
              key={nutrient.name}
              className="bg-white rounded-lg p-6 border border-gray-100 shadow-sm"
            >
              <div className="flex items-start gap-4">
                <div className="p-2 bg-pink-50 rounded-lg">
                  <Info className="h-6 w-6 text-pink-500" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-lg mb-2">{nutrient.name}</h3>
                  <p className="text-gray-600 mb-4">{nutrient.importance}</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm">
                        <span className="font-medium">Daily Needs:</span>{' '}
                        {nutrient.dailyNeeds}
                      </p>
                      <p className="text-sm">
                        <span className="font-medium">Caloric Impact:</span>{' '}
                        {nutrient.calories}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm">
                        <span className="font-medium">Food Sources:</span>{' '}
                        {nutrient.sources.join(', ')}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-6">BMI-Specific Recommendations</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {Object.values(bmiBasedRecommendations).map(category => (
            <div
              key={category.title}
              className="bg-white rounded-lg p-6 border border-gray-100 shadow-sm"
            >
              <div className="flex items-center gap-2 mb-4">
                <Apple className="h-5 w-5 text-pink-500" />
                <h3 className="font-medium">{category.title}</h3>
              </div>
              <ul className="space-y-2">
                {category.recommendations.map((rec, index) => (
                  <li key={index} className="text-sm text-gray-600">
                    • {rec}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}