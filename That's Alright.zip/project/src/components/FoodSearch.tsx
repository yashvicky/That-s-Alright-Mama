import React, { useState } from 'react';
import { Search, Check, X } from 'lucide-react';

export function FoodSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  
  const commonFoods = [
    {
      name: 'Salmon',
      safe: true,
      benefits: 'Rich in omega-3 fatty acids and protein',
      precautions: "Ensure it's fully cooked",
    },
    {
      name: 'Soft Cheese',
      safe: false,
      benefits: '',
      precautions: 'Avoid unpasteurized soft cheeses during pregnancy',
    },
    {
      name: 'Spinach',
      safe: true,
      benefits: 'High in folate, iron, and fiber',
      precautions: 'Wash thoroughly before consuming',
    },
  ];

  const filteredFoods = commonFoods.filter(food =>
    food.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <h2 className="text-xl font-semibold mb-6">Food Safety Search</h2>
      <div className="relative mb-6">
        <input
          type="text"
          placeholder="Search for a food..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-4 pl-12 rounded-lg border border-gray-200 focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        />
        <Search className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
      </div>

      <div className="space-y-4">
        {filteredFoods.map(food => (
          <div
            key={food.name}
            className="bg-white rounded-lg p-4 border border-gray-100"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-medium">{food.name}</h3>
                  {food.safe ? (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <Check className="h-3 w-3 mr-1" />
                      Safe
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      <X className="h-3 w-3 mr-1" />
                      Avoid
                    </span>
                  )}
                </div>
                {food.benefits && (
                  <p className="text-sm text-gray-600 mb-1">{food.benefits}</p>
                )}
                {food.precautions && (
                  <p className="text-sm text-gray-500">{food.precautions}</p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}