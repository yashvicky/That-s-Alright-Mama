import React from 'react';
import { Crown } from 'lucide-react';

export function PremiumBanner() {
  return (
    <div className="bg-gradient-to-r from-pink-500 to-purple-600 text-white p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-4">
        <div className="p-3 bg-white bg-opacity-20 rounded-full">
          <Crown className="h-8 w-8" />
        </div>
        <div>
          <h3 className="text-xl font-semibold mb-2">Upgrade to Premium</h3>
          <p className="mb-4">Get access to personalized meal plans, expert consultations, and more!</p>
          <button className="bg-white text-purple-600 px-6 py-2 rounded-full font-medium hover:bg-opacity-90 transition-colors">
            Upgrade Now
          </button>
        </div>
      </div>
    </div>
  );
}