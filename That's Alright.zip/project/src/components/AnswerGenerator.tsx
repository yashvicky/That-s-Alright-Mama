import React, { useState, useEffect } from 'react';
import { Search, Loader } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { supabase } from '../lib/supabase';

interface AnswerGeneratorProps {
  transcript: string;
}

export function AnswerGenerator({ transcript }: AnswerGeneratorProps) {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const analyzeQuestion = async () => {
    if (!question.trim()) return;

    setIsLoading(true);
    try {
      // Store the question and context in Supabase
      const { data, error } = await supabase
        .from('interview_qa')
        .insert([
          {
            question,
            context: transcript,
            timestamp: new Date().toISOString(),
          },
        ])
        .select()
        .single();

      if (error) throw error;

      // For now, we'll use a mock response
      // In a real app, you'd integrate with an AI service
      const mockAnswer = generateMockAnswer(question);
      setAnswer(mockAnswer);
    } catch (err) {
      console.error('Error analyzing question:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const generateMockAnswer = (q: string) => {
    // Simple mock responses based on keywords
    if (q.toLowerCase().includes('javascript')) {
      return `Here's a technical explanation about JavaScript:

## Key Points
- JavaScript is a high-level, interpreted programming language
- It's primarily used for web development
- Supports both functional and object-oriented programming

## Example Code
\`\`\`javascript
const example = () => {
  console.log("Hello, JavaScript!");
};
\`\`\`

Would you like me to elaborate on any specific aspect?`;
    }
    
    return 'I detected a technical question. Could you please provide more context or rephrase your question?';
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Ask a technical question about the interview..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            className="w-full p-4 pl-12 rounded-lg border border-gray-200 focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
          />
          <Search className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
        </div>
        <button
          onClick={analyzeQuestion}
          disabled={isLoading || !question.trim()}
          className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <>
              <Loader className="h-5 w-5 animate-spin" />
              Analyzing...
            </>
          ) : (
            'Get Answer'
          )}
        </button>
      </div>

      {answer && (
        <div className="bg-gray-50 rounded-lg p-6">
          <ReactMarkdown className="prose max-w-none">
            {answer}
          </ReactMarkdown>
        </div>
      )}
    </div>
  );
}