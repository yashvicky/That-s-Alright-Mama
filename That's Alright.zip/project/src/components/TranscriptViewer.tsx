import React from 'react';
import { useTranscriptStore } from '../store/transcriptStore';

export function TranscriptViewer() {
  const { transcript } = useTranscriptStore();

  return (
    <div className="bg-gray-50 rounded-lg p-4 h-[300px] overflow-y-auto">
      <p className="whitespace-pre-wrap">
        {transcript || 'Transcript will appear here...'}
      </p>
    </div>
  );
}