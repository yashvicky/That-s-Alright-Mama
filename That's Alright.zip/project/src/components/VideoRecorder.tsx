import React, { useRef, useEffect } from 'react';
import { Video, StopCircle } from 'lucide-react';
import { useTranscriptStore } from '../store/transcriptStore';

interface VideoRecorderProps {
  isRecording: boolean;
  onRecordingChange: (recording: boolean) => void;
}

export function VideoRecorder({ isRecording, onRecordingChange }: VideoRecorderProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const { addToTranscript, clearTranscript } = useTranscriptStore();

  useEffect(() => {
    let recognition: SpeechRecognition | null = null;

    const startRecording = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }

        // Initialize speech recognition
        recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.continuous = true;
        recognition.interimResults = true;

        recognition.onresult = (event) => {
          const result = event.results[event.results.length - 1];
          if (result.isFinal) {
            addToTranscript(result[0].transcript);
          }
        };

        recognition.start();
        mediaRecorderRef.current = new MediaRecorder(stream);
        mediaRecorderRef.current.start();
      } catch (err) {
        console.error('Error accessing media devices:', err);
      }
    };

    const stopRecording = () => {
      if (mediaRecorderRef.current) {
        mediaRecorderRef.current.stop();
        const tracks = videoRef.current?.srcObject as MediaStream;
        tracks?.getTracks().forEach(track => track.stop());
      }
      if (recognition) {
        recognition.stop();
      }
    };

    if (isRecording) {
      startRecording();
    } else {
      stopRecording();
    }

    return () => {
      stopRecording();
    };
  }, [isRecording, addToTranscript]);

  const handleToggleRecording = () => {
    if (!isRecording) {
      clearTranscript();
    }
    onRecordingChange(!isRecording);
  };

  return (
    <div className="space-y-4">
      <video
        ref={videoRef}
        autoPlay
        muted
        playsInline
        className="w-full aspect-video bg-gray-100 rounded-lg"
      />
      <button
        onClick={handleToggleRecording}
        className={`w-full py-2 px-4 rounded-md flex items-center justify-center gap-2 ${
          isRecording
            ? 'bg-red-500 hover:bg-red-600'
            : 'bg-blue-500 hover:bg-blue-600'
        } text-white transition-colors`}
      >
        {isRecording ? (
          <>
            <StopCircle className="h-5 w-5" />
            Stop Recording
          </>
        ) : (
          <>
            <Video className="h-5 w-5" />
            Start Recording
          </>
        )}
      </button>
    </div>
  );
}