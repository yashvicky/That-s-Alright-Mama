import React, { useState } from 'react';
import { Video, Mic, StopCircle, Brain } from 'lucide-react';
import { VideoRecorder } from './components/VideoRecorder';
import { TranscriptViewer } from './components/TranscriptViewer';
import { AnswerGenerator } from './components/AnswerGenerator';
import { useTranscriptStore } from './store/transcriptStore';

function App() {
  const [isRecording, setIsRecording] = useState(false);
  const { transcript } = useTranscriptStore();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-semibold text-blue-600 flex items-center gap-2">
              <Brain className="h-6 w-6" />
              InterviewAI Assistant
            </h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Video className="h-5 w-5 text-blue-500" />
                  Video Input
                </h2>
                <VideoRecorder
                  isRecording={isRecording}
                  onRecordingChange={setIsRecording}
                />
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Mic className="h-5 w-5 text-blue-500" />
                  Live Transcript
                </h2>
                <TranscriptViewer />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Brain className="h-5 w-5 text-blue-500" />
                AI Analysis & Answers
              </h2>
              <AnswerGenerator transcript={transcript} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;