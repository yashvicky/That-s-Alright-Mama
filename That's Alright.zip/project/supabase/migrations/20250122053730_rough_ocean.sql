/*
  # Interview Assistant Schema

  1. Tables
    - interview_qa
      - Stores questions and answers from interviews
      - Includes context from transcripts
    - interview_sessions
      - Tracks interview recording sessions
      - Stores metadata and transcripts

  2. Security
    - RLS enabled on all tables
    - Policies for user data access
*/

-- Create interview_qa table
CREATE TABLE interview_qa (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users,
  question text NOT NULL,
  context text,
  answer text,
  timestamp timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE interview_qa ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own QA"
  ON interview_qa FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create QA"
  ON interview_qa FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create interview_sessions table
CREATE TABLE interview_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users,
  transcript text,
  duration integer,
  started_at timestamptz DEFAULT now(),
  ended_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE interview_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own sessions"
  ON interview_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create sessions"
  ON interview_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);